
import React, { createContext, useContext, ReactNode, useCallback } from 'react';
import { Order, OrderItem, OrderStatus, OrderItemStatus, SelectedModifierOption } from '../types';
import useLocalStorage from '../hooks/useLocalStorage';
import { v4 as uuidv4 } from 'uuid';
import { defaultOrders } from '../data/defaultData';
import { useMenu } from './MenuContext';
import { useRecipe } from './RecipeContext'; 
import { useInventory } from './InventoryContext'; 

interface OrderContextType {
  orders: Order[];
  addOrder: (
    orderData: {
      items: { menuItemId: string; quantity: number; selectedModifiers?: SelectedModifierOption[] }[];
      tableNumber?: string;
      pax?: number;
      status?: OrderStatus; 
      paymentMethod?: 'cash' | 'card' | 'gcash';
      amountReceived?: number;
      isPaid?: boolean;
    }
  ) => Order;
  updateOrderItemStatus: (orderId: string, orderItemId: string, newKDSStatus: OrderItemStatus) => void;
  updateOrderStatus: (
    orderId: string, 
    newStatus: OrderStatus, 
    paymentDetails?: { 
        paymentMethod: 'cash' | 'card' | 'gcash'; 
        amountReceived?: number; 
        changeGiven?: number; 
        isPaid: boolean;
    }
  ) => void;
  getOrdersByStatus: (statuses: OrderStatus[]) => Order[];
  getOrderById: (orderId: string) => Order | undefined;
  generateTokenNumber: () => string;
  updateHeldOrder: (
    orderId: string, 
    updatedData: {
      items: OrderItem[];
      tableNumber?: string;
      pax?: number;
      paymentMethod?: 'cash' | 'card' | 'gcash'; 
      amountReceived?: number;
    }
  ) => void;
  markOrderItemDeliveredByBar: (orderId: string, orderItemId: string) => void; 
}

const OrderContext = createContext<OrderContextType | undefined>(undefined);

const determineOverallOrderStatus = (items: OrderItem[], currentOverallStatus?: OrderStatus): OrderStatus => {
    if (currentOverallStatus === OrderStatus.ON_HOLD) return OrderStatus.ON_HOLD;
    if (currentOverallStatus === OrderStatus.COMPLETED) return OrderStatus.COMPLETED;
    if (currentOverallStatus === OrderStatus.CANCELLED) return OrderStatus.CANCELLED;

    const activeKDSItems = items.filter(item => item.status !== OrderItemStatus.CANCELLED);
    if (activeKDSItems.length === 0 && items.length > 0) return OrderStatus.CANCELLED; // If all original items are cancelled

    const allKDSItemsReady = activeKDSItems.every(item => item.status === OrderItemStatus.READY || item.status === OrderItemStatus.AWAITING_DELIVERY || item.status === OrderItemStatus.DELIVERED_TO_CUSTOMER);
    const allKDSItemsDeliveredByBar = activeKDSItems.every(item => item.status === OrderItemStatus.DELIVERED_TO_CUSTOMER);
    
    if (allKDSItemsReady && allKDSItemsDeliveredByBar) return OrderStatus.COMPLETED;
    if (allKDSItemsReady && activeKDSItems.some(item => item.status === OrderItemStatus.DELIVERED_TO_CUSTOMER)) return OrderStatus.DELIVERY_IN_PROGRESS;
    if (allKDSItemsReady) return OrderStatus.READY_FOR_DELIVERY;

    if (activeKDSItems.some(item => item.status === OrderItemStatus.PREPARING)) return OrderStatus.PREPARING;
    if (activeKDSItems.some(item => item.status === OrderItemStatus.READY || item.status === OrderItemStatus.AWAITING_DELIVERY) && 
        activeKDSItems.some(item => item.status === OrderItemStatus.PENDING || item.status === OrderItemStatus.PREPARING)) return OrderStatus.PARTIALLY_READY;
    
    if (items.every(item => item.status === OrderItemStatus.PENDING)) return OrderStatus.PENDING;

    return currentOverallStatus || OrderStatus.PENDING; // Fallback, or keep current if no clear transition
};


export const OrderProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [orders, setOrders] = useLocalStorage<Order[]>('orders', defaultOrders);
  const { getMenuItemById } = useMenu();
  const { getRecipeByMenuItemId } = useRecipe();
  const { deductIngredientStock } = useInventory();
  const [lastTokenDate, setLastTokenDate] = useLocalStorage<string>('lastTokenDate', '');
  const [lastTokenCounter, setLastTokenCounter] = useLocalStorage<number>('lastTokenCounter', 0);

  const generateTokenNumber = useCallback(() => {
    const today = new Date().toISOString().split('T')[0]; 
    let counter = lastTokenCounter;
    if (lastTokenDate !== today) {
      counter = 1;
      setLastTokenDate(today);
    } else {
      counter++;
    }
    setLastTokenCounter(counter);
    return String(counter).padStart(3, '0');
  }, [lastTokenDate, lastTokenCounter, setLastTokenDate, setLastTokenCounter]);

  const performInventoryDeduction = useCallback((orderItems: OrderItem[]) => {
    orderItems.forEach(orderItem => {
      const recipe = getRecipeByMenuItemId(orderItem.menuItemId);
      if (recipe) {
        recipe.items.forEach(recipeIngredient => {
          const totalToDeduct = recipeIngredient.quantity * orderItem.quantity;
          deductIngredientStock(recipeIngredient.ingredientId, totalToDeduct);
        });
      }
    });
  }, [getRecipeByMenuItemId, deductIngredientStock]);

  const addOrder = useCallback((orderData: {
    items: { menuItemId: string; quantity: number; selectedModifiers?: SelectedModifierOption[] }[];
    tableNumber?: string;
    pax?: number;
    status?: OrderStatus;
    paymentMethod?: 'cash' | 'card' | 'gcash';
    amountReceived?: number;
    isPaid?: boolean;
  }): Order => {
    const now = new Date();
    const yyyy = now.getFullYear();
    const mm = String(now.getMonth() + 1).padStart(2, '0');
    const dd = String(now.getDate()).padStart(2, '0');
    const dailyOrderCount = orders.filter(o => o.orderTime && new Date(o.orderTime).toDateString() === now.toDateString()).length + 1;
    const internalOrderNumber = `${yyyy}${mm}${dd}-${String(dailyOrderCount).padStart(4, '0')}`;
    
    const customerTokenNumber = (orderData.status === OrderStatus.ON_HOLD && !orderData.isPaid) 
                                ? 'HELD' 
                                : generateTokenNumber();

    let totalAmount = 0;
    const newOrderItems: OrderItem[] = orderData.items.map(itemData => {
      const menuItem = getMenuItemById(itemData.menuItemId);
      if (!menuItem) throw new Error(`Menu item with ID ${itemData.menuItemId} not found.`);
      
      let itemSubTotal = menuItem.price * itemData.quantity;
      if (itemData.selectedModifiers) {
        itemData.selectedModifiers.forEach(mod => {
          itemSubTotal += mod.priceChange * itemData.quantity;
        });
      }
      totalAmount += itemSubTotal;

      return {
        id: uuidv4(),
        menuItemId: menuItem.id,
        menuItemName: menuItem.name,
        quantity: itemData.quantity,
        priceAtOrder: menuItem.price, 
        status: OrderItemStatus.PENDING, 
        selectedModifiers: itemData.selectedModifiers || [],
      };
    });

    const changeGiven = (orderData.paymentMethod === 'cash' && orderData.amountReceived && totalAmount > 0) 
                        ? Math.max(0, orderData.amountReceived - totalAmount) 
                        : undefined;
    
    const newOrder: Order = {
      id: uuidv4(),
      orderNumber: internalOrderNumber,
      tokenNumber: customerTokenNumber,
      items: newOrderItems,
      status: orderData.status || OrderStatus.PENDING,
      totalAmount,
      orderTime: now,
      tableNumber: orderData.tableNumber || undefined,
      pax: orderData.pax || undefined,
      paymentMethod: orderData.paymentMethod,
      amountReceived: orderData.amountReceived,
      changeGiven: changeGiven,
      isPaid: orderData.isPaid || false,
      lastKDSNotifiedTime: (orderData.status === OrderStatus.PENDING || !orderData.status) ? Date.now() : undefined,
    };

    if (newOrder.isPaid && newOrder.status !== OrderStatus.ON_HOLD) {
      performInventoryDeduction(newOrder.items);
    }

    setOrders(prev => [newOrder, ...prev]);
    return newOrder;
  }, [setOrders, orders, getMenuItemById, generateTokenNumber, performInventoryDeduction]);
  
  const updateHeldOrder = useCallback((
    orderId: string, 
    updatedData: {
        items: OrderItem[];
        tableNumber?: string;
        pax?: number;
        paymentMethod?: 'cash' | 'card' | 'gcash'; 
        amountReceived?: number;
    }
  ) => {
    setOrders(prevOrders =>
      prevOrders.map(order => {
        if (order.id === orderId && order.status === OrderStatus.ON_HOLD) {
          let newTotalAmount = 0;
          updatedData.items.forEach(item => {
            let itemSubTotal = item.priceAtOrder * item.quantity;
            if (item.selectedModifiers) {
                item.selectedModifiers.forEach(mod => {
                    itemSubTotal += mod.priceChange * item.quantity;
                });
            }
            newTotalAmount += itemSubTotal;
          });
          
          return { 
            ...order, 
            items: updatedData.items,
            tableNumber: updatedData.tableNumber !== undefined ? updatedData.tableNumber : order.tableNumber,
            pax: updatedData.pax !== undefined ? updatedData.pax : order.pax,
            totalAmount: newTotalAmount,
            paymentMethod: updatedData.paymentMethod !== undefined ? updatedData.paymentMethod : order.paymentMethod,
            amountReceived: updatedData.amountReceived !== undefined ? updatedData.amountReceived : order.amountReceived,
          };
        }
        return order;
      })
    );
  }, [setOrders]);

  const updateOrderItemStatus = useCallback((orderId: string, orderItemId: string, newKDSStatus: OrderItemStatus) => {
    setOrders(prevOrders => {
      return prevOrders.map(order => {
        if (order.id === orderId) {
          const updatedItems = order.items.map(item => {
            if (item.id === orderItemId) {
              const statusForBarPerspective = newKDSStatus === OrderItemStatus.READY && item.status !== OrderItemStatus.DELIVERED_TO_CUSTOMER 
                                              ? OrderItemStatus.AWAITING_DELIVERY 
                                              : newKDSStatus;
              return { ...item, status: statusForBarPerspective };
            }
            return item;
          });
          const newOverallStatus = determineOverallOrderStatus(updatedItems, order.status);
          return { ...order, items: updatedItems, status: newOverallStatus };
        }
        return order;
      });
    });
  }, [setOrders]);
  
  const markOrderItemDeliveredByBar = useCallback((orderId: string, orderItemId: string) => {
    setOrders(prevOrders =>
      prevOrders.map(order => {
        if (order.id === orderId) {
          const updatedItems = order.items.map(item =>
            item.id === orderItemId ? { ...item, status: OrderItemStatus.DELIVERED_TO_CUSTOMER } : item
          );
          const newOverallStatus = determineOverallOrderStatus(updatedItems, order.status);
          return { ...order, items: updatedItems, status: newOverallStatus };
        }
        return order;
      })
    );
  }, [setOrders]);


  const updateOrderStatus = useCallback((
    orderId: string, 
    newStatus: OrderStatus, 
    paymentDetails?: { 
        paymentMethod: 'cash' | 'card' | 'gcash'; 
        amountReceived?: number; 
        changeGiven?: number; 
        isPaid: boolean;
    }
  ) => {
    setOrders(prevOrders =>
      prevOrders.map(order => {
        if (order.id === orderId) {
          let updatedOrder = { ...order, status: newStatus, lastKDSNotifiedTime: Date.now() }; 

          if (order.status === OrderStatus.ON_HOLD && newStatus === OrderStatus.PENDING && paymentDetails) {
            updatedOrder.tokenNumber = generateTokenNumber();
            updatedOrder.isPaid = paymentDetails.isPaid;
            updatedOrder.paymentMethod = paymentDetails.paymentMethod;
            updatedOrder.amountReceived = paymentDetails.amountReceived;
            updatedOrder.changeGiven = paymentDetails.changeGiven;
            
            let newTotalAmount = 0;
            updatedOrder.items.forEach(item => {
                let itemSubTotal = item.priceAtOrder * item.quantity;
                if (item.selectedModifiers) {
                    item.selectedModifiers.forEach(mod => {
                        itemSubTotal += mod.priceChange * item.quantity;
                    });
                }
                newTotalAmount += itemSubTotal;
            });
            updatedOrder.totalAmount = newTotalAmount;

            if (updatedOrder.isPaid) {
              performInventoryDeduction(updatedOrder.items);
            }

          } else if (paymentDetails) {
            updatedOrder = { ...updatedOrder, ...paymentDetails };
          }
          
          if (newStatus === OrderStatus.COMPLETED && !updatedOrder.isPaid) {
            updatedOrder.isPaid = true; 
            if(!updatedOrder.paymentMethod) updatedOrder.paymentMethod = 'cash'; 
            if(updatedOrder.paymentMethod === 'cash' && !updatedOrder.amountReceived){
                 updatedOrder.amountReceived = updatedOrder.totalAmount;
                 updatedOrder.changeGiven = 0;
            }
             performInventoryDeduction(updatedOrder.items);
          }

          // If order is cancelled, set all its items to cancelled
          if (newStatus === OrderStatus.CANCELLED) {
            updatedOrder.items = updatedOrder.items.map(item => ({
              ...item,
              status: OrderItemStatus.CANCELLED
            }));
            // Note: Inventory is NOT restocked automatically here.
          }

          return updatedOrder;
        }
        return order;
      })
    );
  }, [setOrders, generateTokenNumber, performInventoryDeduction]);


  const getOrdersByStatus = useCallback((statuses: OrderStatus[]) => {
    return orders.filter(order => statuses.includes(order.status));
  }, [orders]);

  const getOrderById = useCallback((orderId: string) => {
    return orders.find(order => order.id === orderId);
  }, [orders]);

  return (
    <OrderContext.Provider value={{
      orders,
      addOrder,
      updateOrderItemStatus,
      updateOrderStatus,
      getOrdersByStatus,
      getOrderById,
      generateTokenNumber,
      updateHeldOrder,
      markOrderItemDeliveredByBar,
    }}>
      {children}
    </OrderContext.Provider>
  );
};

export const useOrder = (): OrderContextType => {
  const context = useContext(OrderContext);
  if (context === undefined) {
    throw new Error('useOrder must be used within an OrderProvider');
  }
  return context;
};
