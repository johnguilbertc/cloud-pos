
import React, { createContext, useContext, ReactNode, useState, useEffect, useCallback } from 'react';
import { initializeFirebaseApp, initializeFirestoreDb, defaultConfig, isConfigEffectivelyDefault, FirebaseConfig, PLACEHOLDER_API_KEY, PLACEHOLDER_PROJECT_ID } from '../firebase-config';
import type { Firestore } from 'firebase/firestore';
import type { FirebaseApp } from 'firebase/app';
import { getDocs, collection } from 'firebase/firestore'; 

const FIREBASE_CONFIG_STORAGE_KEY = 'firebaseUserConfig';

export const FIRESTORE_UNAVAILABLE_ERROR_PREFIX = "ACTION_REQUIRED_FIRESTORE_UNAVAILABLE:";

interface FirebaseConfigContextType {
  firebaseConfig: FirebaseConfig;
  db: Firestore | null;
  app: FirebaseApp | null;
  isFirebaseEffectivelyConfigured: boolean;
  isLoading: boolean;
  error: string | null;
  saveAndInitializeFirebase: (newConfig: FirebaseConfig) => Promise<boolean>;
  clearFirebaseConfig: () => void;
}

const FirebaseConfigContext = createContext<FirebaseConfigContextType | undefined>(undefined);

export const FirebaseConfigProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [firebaseConfig, setFirebaseConfig] = useState<FirebaseConfig>(defaultConfig);
  const [db, setDb] = useState<Firestore | null>(null);
  const [app, setApp] = useState<FirebaseApp | null>(null);
  const [isFirebaseEffectivelyConfigured, setIsFirebaseEffectivelyConfigured] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const tryInitializeFirebase = useCallback(async (configToTry: FirebaseConfig): Promise<boolean> => {
    setError(null);
    setIsLoading(true);
    if (isConfigEffectivelyDefault(configToTry)) {
      console.warn("Firebase configuration uses placeholder values. Skipping initialization.");
      setDb(null);
      setApp(null);
      setIsFirebaseEffectivelyConfigured(false);
      setIsLoading(false);
      return false;
    }

    try {
      const validatedConfig = { ...configToTry };
      if (validatedConfig.storageBucket && !validatedConfig.storageBucket.endsWith('appspot.com')) {
        if (validatedConfig.storageBucket.endsWith('.firebasestorage.app')) {
           validatedConfig.storageBucket = validatedConfig.storageBucket.replace('.firebasestorage.app', '.appspot.com');
           console.warn("Corrected storageBucket format from .firebasestorage.app to .appspot.com.");
        } else if (validatedConfig.projectId && validatedConfig.storageBucket === validatedConfig.projectId && !validatedConfig.storageBucket.includes('.')) {
           validatedConfig.storageBucket = `${validatedConfig.projectId}.appspot.com`;
           console.warn(`Corrected storageBucket format from just projectId to ${validatedConfig.projectId}.appspot.com.`);
        }
      }
      
      if (validatedConfig.measurementId === "") {
        validatedConfig.measurementId = undefined;
      }
      
      console.log("Attempting to initialize Firebase with config:", JSON.parse(JSON.stringify(validatedConfig)));

      const initializedApp = initializeFirebaseApp(validatedConfig);
      const initializedDb = initializeFirestoreDb(initializedApp);
      
      await getDocs(collection(initializedDb, "_test_connection_doc_")); 
      
      console.log("Firebase initialized successfully with new config.");
      setApp(initializedApp);
      setDb(initializedDb);
      setFirebaseConfig(validatedConfig);
      setIsFirebaseEffectivelyConfigured(true);
      localStorage.setItem(FIREBASE_CONFIG_STORAGE_KEY, JSON.stringify(validatedConfig));
      setIsLoading(false);
      return true;
    } catch (e) {
      console.error("Failed to initialize Firebase with provided config:", e);
      let detailedError = "Failed to connect to Firebase. Check credentials and Firestore rules. Review the browser console for the exact configuration object used during the attempt.";
      const projectIdForLinks = configToTry.projectId || PLACEHOLDER_PROJECT_ID; 

      if (e instanceof Error) {
        detailedError = e.message; 
        const lowerEMessage = e.message.toLowerCase();
        if (lowerEMessage.includes("service firestore is not available") ||
            lowerEMessage.includes("firestore has not been started") ||
            lowerEMessage.includes("could not reach cloud firestore backend") ||
            (lowerEMessage.includes("cloud firestore api has not been used in project") && lowerEMessage.includes("or it is disabled")) ||
            (lowerEMessage.includes("failed to get document because the client is offline") && isConfigEffectivelyDefault(configToTry)) 
            ) {
          detailedError = `${FIRESTORE_UNAVAILABLE_ERROR_PREFIX}
<strong style="color: #c0392b; font-size: 1.1em;">IMPORTANT: This is an issue with your Firebase project's external setup on Google's servers, not an application bug.</strong>
We understand you're confident in your setup, but the error "'Service firestore is not available'" (or similar, like "'Cloud Firestore API has not been used in project {{PROJECT_ID}} before or it is disabled'") comes *directly from Firebase* when it cannot find or access an active Firestore database for the Project ID ('{{PROJECT_ID}}') you've provided.
The application's Firebase initialization code is standard. <strong style="text-decoration: underline;">The solution lies in meticulously verifying every detail in your Firebase Console.</strong>

Please, very carefully, re-check these critical points:

1.  <strong>Verify Project ID:</strong> Ensure the Project ID '{{PROJECT_ID}}' entered in this form <strong>exactly</strong> matches your Firebase project ID in the console. Typos are common. Also, ensure you are targeting the correct Firebase project if you manage multiple projects or use aliases.
2.  <strong>Enable Firestore & Select Region (MOST CRITICAL):</strong>
    *   Go to your Firebase Console: <a href="https://console.firebase.google.com/project/{{PROJECT_ID_LINK_PART}}/firestore" target="_blank" rel="noopener noreferrer" style="color: #007bff; text-decoration: underline;">Firestore Database for Project '{{PROJECT_ID_LINK_PART}}'</a>.
    *   If prompted, click "<strong>Create database</strong>".
    *   <strong style="color: #c0392b;">Crucially, you MUST SELECT A CLOUD FIRESTORE LOCATION (REGION)</strong> during the database creation process *for this specific project ID*. If this step was missed, Firestore will NOT be available. This is the most frequent cause of this error. Double-check this for the correct project.
3.  <strong>Wait for Provisioning:</strong> After enabling Firestore and selecting a region, it can take <strong>5-10 minutes (sometimes longer)</strong> to fully provision. Please wait patiently.
4.  <strong>Check Cloud Firestore API Status:</strong>
    *   Go to Google Cloud Console: <a href="https://console.cloud.google.com/apis/library/firestore.googleapis.com?project={{PROJECT_ID_LINK_PART}}" target="_blank" rel="noopener noreferrer" style="color: #007bff; text-decoration: underline;">Cloud Firestore API for '{{PROJECT_ID_LINK_PART}}'</a>.
    *   Ensure the "Cloud Firestore API" is <strong>ENABLED</strong> for this project.
5.  <strong>Billing Active:</strong> Confirm your Google Cloud project linked to this Firebase project has active billing.

<strong>Debugging Tip:</strong> Check your browser's developer console. The application logs the exact configuration object it attempted to use for Firebase initialization. This can help you verify the values. Consider using the "Verify Your Entered Configuration" section that appears with this error in the app to compare values side-by-side with your console.

After carefully re-verifying ALL these points in the Firebase console, <strong>perform a hard refresh of this application page (Ctrl+Shift+R or Cmd+Shift+R)</strong>, then try submitting this configuration form again.`;
        } else if (lowerEMessage.includes("missing or insufficient permissions")) {
          detailedError = `Firestore permission denied. Please check your Firestore security rules in the Firebase console (Project '${projectIdForLinks}'). For development, you might start with test mode rules: \`rules_version = '2'; service cloud.firestore { match /databases/{database}/documents { match /{document=**} { allow read, write: if true; } } }\` (Remember to secure these for production).`;
        } else if (lowerEMessage.includes("invalid api key")) {
            detailedError = `Invalid Firebase API Key. Please verify the API key in your Firebase project settings (Project '${projectIdForLinks}') and ensure it's correctly entered in the form.`;
        } else if (lowerEMessage.includes("authdomain")) {
            detailedError = `There might be an issue with the Auth Domain configuration: ${e.message}. Please verify it in your Firebase project settings (Project '${projectIdForLinks}').`;
        } else if (lowerEMessage.includes("storagebucket") || lowerEMessage.includes("storage bucket")) {
             const storageBucketHint = configToTry.projectId ? `It should typically be in the format '${configToTry.projectId}.appspot.com'.` : "It should typically be in the format 'your-project-id.appspot.com'.";
            detailedError = `There might be an issue with the Storage Bucket configuration: ${e.message}. ${storageBucketHint} Please check your Firebase project settings (Project '${projectIdForLinks}').`;
        }
      }
      setError(detailedError);
      setDb(null);
      setApp(null);
      setIsFirebaseEffectivelyConfigured(false);
      setIsLoading(false);
      return false;
    }
  }, []);

  useEffect(() => {
    const loadConfig = async () => {
      setIsLoading(true);
      const storedConfigStr = localStorage.getItem(FIREBASE_CONFIG_STORAGE_KEY);
      let configToUse = defaultConfig;
      if (storedConfigStr) {
        try {
          const storedConfig = JSON.parse(storedConfigStr) as FirebaseConfig;
          if (storedConfig.apiKey && storedConfig.apiKey !== PLACEHOLDER_API_KEY && storedConfig.projectId && storedConfig.projectId !== PLACEHOLDER_PROJECT_ID) {
             if (storedConfig.storageBucket && !storedConfig.storageBucket.endsWith('appspot.com')) {
                if (storedConfig.storageBucket.endsWith('.firebasestorage.app')) {
                    storedConfig.storageBucket = storedConfig.storageBucket.replace('.firebasestorage.app', '.appspot.com');
                } else if (storedConfig.projectId && storedConfig.storageBucket === storedConfig.projectId && !storedConfig.storageBucket.includes('.')) {
                    storedConfig.storageBucket = `${storedConfig.projectId}.appspot.com`;
                }
            }
            if (storedConfig.measurementId === "") {
                storedConfig.measurementId = undefined;
            }
            configToUse = storedConfig;
          } else {
             localStorage.removeItem(FIREBASE_CONFIG_STORAGE_KEY); 
          }
        } catch (e) {
          console.error("Failed to parse stored Firebase config:", e);
          localStorage.removeItem(FIREBASE_CONFIG_STORAGE_KEY);
        }
      }
      await tryInitializeFirebase(configToUse);
    };
    loadConfig();
  }, [tryInitializeFirebase]);

  const saveAndInitializeFirebase = async (newConfig: FirebaseConfig): Promise<boolean> => {
    return await tryInitializeFirebase(newConfig);
  };

  const clearFirebaseConfig = () => {
    localStorage.removeItem(FIREBASE_CONFIG_STORAGE_KEY);
    setFirebaseConfig(defaultConfig); 
    setDb(null);
    setApp(null);
    setIsFirebaseEffectivelyConfigured(false);
    setError(null); 
  };

  return (
    <FirebaseConfigContext.Provider value={{
      firebaseConfig,
      db,
      app,
      isFirebaseEffectivelyConfigured,
      isLoading,
      error,
      saveAndInitializeFirebase,
      clearFirebaseConfig,
    }}>
      {children}
    </FirebaseConfigContext.Provider>
  );
};

export const useFirebaseConfig = (): FirebaseConfigContextType => {
  const context = useContext(FirebaseConfigContext);
  if (context === undefined) {
    throw new Error('useFirebaseConfig must be used within a FirebaseConfigProvider');
  }
  return context;
};
