import React, { createContext, useContext, ReactNode, useCallback, useState, useEffect } from 'react';
import { Category, MenuItem } from '../types';
import { 
  fetchCategoriesAPI, addCategoryAPI, updateCategoryAPI, deleteCategoryAPI,
  fetchMenuItemsAPI, addMenuItemAPI, updateMenuItemAPI, deleteMenuItemAPI
} from '../services/menuService';
import { defaultCategories, defaultMenuItems } from '../data/defaultData';
import { collection, getDocs, writeBatch, doc, setDoc, Firestore } from 'firebase/firestore';
import { useFirebaseConfig } from './FirebaseConfigContext'; // Import useFirebaseConfig


interface MenuContextType {
  categories: Category[];
  menuItems: MenuItem[];
  isLoading: boolean;
  error: string | null;
  addCategory: (category: Omit<Category, 'id'>) => Promise<void>;
  updateCategory: (category: Category) => Promise<void>;
  deleteCategory: (categoryId: string) => Promise<string[]>; 
  getCategoryById: (categoryId: string) => Category | undefined;
  addMenuItem: (item: Omit<MenuItem, 'id'> & { id?: string }) => Promise<MenuItem | undefined>;
  updateMenuItem: (item: MenuItem) => Promise<void>;
  deleteMenuItem: (itemId: string) => Promise<void>; 
  getMenuItemById: (itemId: string) => MenuItem | undefined;
  getMenuItemsByCategoryId: (categoryId: string) => MenuItem[];
  refreshMenuData: () => Promise<void>;
}

const MenuContext = createContext<MenuContextType | undefined>(undefined);

// --- One-time Data Seeding for Development ---
const seedInitialData = async (db: Firestore) => {
  console.log("Checking if initial data seeding is required for menu...");
  try {
    const categoriesSnapshot = await getDocs(collection(db, 'categories'));
    if (categoriesSnapshot.empty) {
      console.log("Firestore 'categories' collection is empty. Seeding default categories and menu items...");
      const batch = writeBatch(db);

      defaultCategories.forEach(category => {
        const categoryRef = doc(db, 'categories', category.id);
        batch.set(categoryRef, { name: category.name, description: category.description });
      });

      defaultMenuItems.forEach(menuItem => {
        const menuItemRef = doc(db, 'menuItems', menuItem.id);
        const { id, ...itemData } = menuItem; 
        batch.set(menuItemRef, itemData);
      });

      await batch.commit();
      console.log("Default categories and menu items seeded successfully to Firestore.");
      return true;
    } else {
      console.log("'categories' collection is not empty. Skipping seeding.");
      return false;
    }
  } catch (error) {
    console.error("Error during initial data seeding for menu:", error);
    throw new Error("Failed to seed initial menu data. Please check Firestore connection and permissions.");
  }
};
// --- End Seeding Logic ---

export const MenuProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { db: firestoreDb, isFirebaseEffectivelyConfigured, isLoading: isFirebaseConfigLoading } = useFirebaseConfig();
  const [categories, setCategories] = useState<Category[]>([]);
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [isSeeding, setIsSeeding] = useState<boolean>(true);

  const loadData = useCallback(async (forceRefresh = false) => {
    if (!firestoreDb) {
      setError("Firestore is not configured. Cannot load menu data.");
      setIsLoading(false);
      return;
    }
    if (!forceRefresh && !isSeeding) setIsLoading(true);
    setError(null);
    try {
      const [fetchedCategories, fetchedMenuItems] = await Promise.all([
        fetchCategoriesAPI(firestoreDb),
        fetchMenuItemsAPI(firestoreDb)
      ]);
      setCategories(fetchedCategories);
      setMenuItems(fetchedMenuItems);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to load menu data from Firestore.");
      console.error("Error loading menu data from Firestore:", e);
    } finally {
      if (!forceRefresh && !isSeeding) setIsLoading(false);
    }
  }, [firestoreDb, isSeeding]);

  useEffect(() => {
    if (!isFirebaseEffectivelyConfigured || isFirebaseConfigLoading) {
      setIsLoading(isFirebaseConfigLoading);
      if(!isFirebaseConfigLoading && !isFirebaseEffectivelyConfigured) setError("Firebase not configured.");
      return; // Don't proceed if Firebase isn't ready
    }

    const initializeAndLoad = async () => {
        if (!firestoreDb) {
          setIsLoading(false);
          setIsSeeding(false);
          setError("Firestore database instance is not available for menu operations.");
          return;
        }
        setIsLoading(true);
        try {
            await seedInitialData(firestoreDb);
        } catch (seedError) {
            setError(seedError instanceof Error ? seedError.message : "Data seeding failed.");
            setIsLoading(false);
            setIsSeeding(false);
            return;
        }
        setIsSeeding(false);
        await loadData(true);
        setIsLoading(false);
    };
    initializeAndLoad();
  }, [firestoreDb, isFirebaseEffectivelyConfigured, isFirebaseConfigLoading, loadData]);


  const addCategory = useCallback(async (categoryData: Omit<Category, 'id'>) => {
    if (!firestoreDb) throw new Error("Firestore not available");
    setIsLoading(true);
    try {
      await addCategoryAPI(firestoreDb, categoryData);
      await loadData(true);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to add category");
      console.error("Error adding category:", e);
      throw e;
    } finally {
      setIsLoading(false);
    }
  }, [loadData, firestoreDb]);

  const updateCategory = useCallback(async (updatedCategory: Category) => {
    if (!firestoreDb) throw new Error("Firestore not available");
    setIsLoading(true);
    try {
      await updateCategoryAPI(firestoreDb, updatedCategory);
      await loadData(true);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to update category");
      console.error("Error updating category:", e);
      throw e;
    } finally {
      setIsLoading(false);
    }
  }, [loadData, firestoreDb]);

  const deleteCategory = useCallback(async (categoryId: string): Promise<string[]> => {
    if (!firestoreDb) throw new Error("Firestore not available");
    setIsLoading(true);
    try {
      const { affectedMenuItemIds } = await deleteCategoryAPI(firestoreDb, categoryId);
      await loadData(true);
      setError(null);
      return affectedMenuItemIds;
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to delete category");
      console.error("Error deleting category:", e);
      throw e;
    } finally {
      setIsLoading(false);
    }
  }, [loadData, firestoreDb]);
  
  const getCategoryById = useCallback((categoryId: string) => {
    return categories.find(cat => cat.id === categoryId);
  }, [categories]);

  const addMenuItem = useCallback(async (itemData: Omit<MenuItem, 'id'> & { id?: string }): Promise<MenuItem | undefined> => {
    if (!firestoreDb) throw new Error("Firestore not available");
    setIsLoading(true);
    try {
      // The addMenuItemAPI now needs db. If itemData includes an id (for seeding), the API handles it.
      const newItem = await addMenuItemAPI(firestoreDb, itemData); 
      await loadData(true);
      setError(null);
      // Find the newly added/seeded item in the refreshed list to return it
      const refreshedItems = await fetchMenuItemsAPI(firestoreDb); // Fetch again to be sure
      return refreshedItems.find(item => item.id === newItem.id);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to add menu item");
      console.error("Error adding menu item:", e);
      throw e;
    } finally {
      setIsLoading(false);
    }
  }, [loadData, firestoreDb]);

  const updateMenuItem = useCallback(async (updatedItem: MenuItem) => {
    if (!firestoreDb) throw new Error("Firestore not available");
    setIsLoading(true);
    try {
      await updateMenuItemAPI(firestoreDb, updatedItem);
      await loadData(true);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to update menu item");
      console.error("Error updating menu item:", e);
      throw e;
    } finally {
      setIsLoading(false);
    }
  }, [loadData, firestoreDb]);

  const deleteMenuItem = useCallback(async (itemId: string) => {
    if (!firestoreDb) throw new Error("Firestore not available");
    setIsLoading(true);
    try {
      await deleteMenuItemAPI(firestoreDb, itemId);
      await loadData(true);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to delete menu item");
      console.error("Error deleting menu item:", e);
      throw e;
    } finally {
      setIsLoading(false);
    }
  }, [loadData, firestoreDb]);

  const getMenuItemById = useCallback((itemId: string) => {
    return menuItems.find(item => item.id === itemId);
  }, [menuItems]);

  const getMenuItemsByCategoryId = useCallback((categoryId: string) => {
    return menuItems.filter(item => item.categoryId === categoryId);
  }, [menuItems]);

  return (
    <MenuContext.Provider value={{ 
      categories, 
      menuItems, 
      isLoading: isLoading || isSeeding || isFirebaseConfigLoading,
      error,
      addCategory, 
      updateCategory, 
      deleteCategory,
      getCategoryById,
      addMenuItem, 
      updateMenuItem, 
      deleteMenuItem,
      getMenuItemById,
      getMenuItemsByCategoryId,
      refreshMenuData: () => loadData(true),
    }}>
      {children}
    </MenuContext.Provider>
  );
};

export const useMenu = (): MenuContextType => {
  const context = useContext(MenuContext);
  if (context === undefined) {
    throw new Error('useMenu must be used within a MenuProvider');
  }
  return context;
};
