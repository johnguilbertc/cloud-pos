
// firebase-config.ts
import { initializeApp, FirebaseApp } from "firebase/app";
import { getFirestore, Firestore } from "firebase/firestore";

// Define a type for the Firebase config object for clarity
export interface FirebaseConfig {
  apiKey: string;
  authDomain: string;
  projectId: string;
  storageBucket: string;
  messagingSenderId: string;
  appId: string;
  measurementId?: string; // Added measurementId as optional, as it's in user's config
}

// Placeholder for API key, used to check if config is default
export const PLACEHOLDER_API_KEY = "YOUR_FIREBASE_API_KEY_HERE";
export const PLACEHOLDER_PROJECT_ID = "YOUR_FIREBASE_PROJECT_ID_HERE";


// Default configuration object with user-provided values
// This will be used if no configuration is found in localStorage
export const defaultConfig: FirebaseConfig = {
  apiKey: "AIzaSyAE5-7Wz-_ikOPXwPNksyiB-K3hDEFFGBk",
  authDomain: "cloudpos-221c7.firebaseapp.com",
  projectId: "cloudpos-221c7",
  storageBucket: "cloudpos-221c7.appspot.com", // Corrected from user's firebasestorage.app to appspot.com as per typical Firebase config
  messagingSenderId: "193219675434",
  appId: "1:193219675434:web:e5ff23469d6bfaf0af0a53",
  measurementId: "G-CY7L7E5R50" // Included measurementId
};

// Functions to initialize Firebase with a given config
// These will be called by the FirebaseConfigContext
export const initializeFirebaseApp = (config: FirebaseConfig): FirebaseApp => {
  return initializeApp(config);
};

export const initializeFirestoreDb = (app: FirebaseApp): Firestore => {
  return getFirestore(app);
};

// Helper function to check if the current config is just placeholders
export const isConfigEffectivelyDefault = (config: FirebaseConfig): boolean => {
  return config.apiKey === PLACEHOLDER_API_KEY || config.projectId === PLACEHOLDER_PROJECT_ID;
};
